<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id16458878_putriwulan","%ADI[u9<SKV<DbPW","id16458878_kisekimirai") or die ("could not connect database");
?>